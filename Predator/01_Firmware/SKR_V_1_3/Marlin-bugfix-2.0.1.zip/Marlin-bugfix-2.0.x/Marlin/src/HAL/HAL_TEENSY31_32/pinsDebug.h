#error "Debug pins is not supported on the Teensy 3.1 / 3.2 Platform!"
